/** Automatically generated file. DO NOT MODIFY */
package com.appspot.azbmobi.pt4you;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
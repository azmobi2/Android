/** Automatically generated file. DO NOT MODIFY */
package com.appspot.azbmobi.eu4you;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}